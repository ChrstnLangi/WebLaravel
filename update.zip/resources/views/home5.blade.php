<div class="section-get-hired">
    <div class="page-padding">
      <div class="container-large">
        <div class="padding-vertical padding-xhuge">
          <div class="margin-bottom margin-large">
            <div class="text-align-center">
              <h2 data-w-id="1579e766-6a71-64b7-84c9-cb0e0cfb1a91" style="opacity:0" class="max-width-mobile">Lorem ipsum dolor sit</h2>
              <div class="underline-wrapper"><img src="Assets/span.png"  loading="lazy" data-w-id="1579e766-6a71-64b7-84c9-cb0e0cfb1a94" style="opacity:0" alt="" class="get-hired-underline" /></div>
            </div>
          </div>
          <section class="layout2-wrapper has-custom-margin">
            <div class="layout2-left-align">
              <div id="w-node-ffac12f3-0395-fb3f-b216-7a7e9916949c-2897c137" class="layout-image-wrapper"><img src={{ $help[0]['img'] }} loading="lazy" width="466" data-w-id="ffac12f3-0395-fb3f-b216-7a7e9916949d" alt="" sizes="(max-width: 479px) 68vw, (max-width: 767px) 53vw, (max-width: 991px) 42vw, (max-width: 1439px) 279.59375px, 419.390625px" class="layout2-image is-60" /></div>
              <div id="w-node-ffac12f3-0395-fb3f-b216-7a7e9916949e-2897c137" data-w-id="ffac12f3-0395-fb3f-b216-7a7e9916949e" class="layout-content2">
                <h3 class="layout-subheading2"><strong>{{ $help[0]['judul'] }}</strong><br /></h3>
                <div class="margin-top margin-small">
                  <p>{{ $help[0]['deskripsi'] }}<br /></p>
                </div>
              </div>
            </div>
          </section>
          <section class="layout1-wrapper has-margin-bottom">
            <div class="layout1-right-align">
              <div id="w-node-b4602805-7765-656c-e268-09ed0263dff7-2897c137" data-w-id="b4602805-7765-656c-e268-09ed0263dff7" class="layout-content1">
                <h3 class="layout-subheading2"><strong>{{ $help[1]['judul'] }}</strong><br /></h3>
                <div class="margin-top margin-small">
                  <p>S{{ $help[1]['deskripsi'] }}<br /></p>
                </div>
              </div>
              <div id="w-node-b4602805-7765-656c-e268-09ed0263e002-2897c137" data-w-id="b4602805-7765-656c-e268-09ed0263e002" class="layout-image-wrapper is-justify-left"><img src={{ $help[1]['img'] }} loading="lazy" width="466" alt="" sizes="(max-width: 479px) 59vw, (max-width: 767px) 46vw, (max-width: 991px) 47vw, (max-width: 1439px) 279.59375px, 466px" class="layout1-image" /></div>
            </div>
          </section>
          <section class="layout2-wrapper is-custom-margin">
            <div class="layout2-left-align">
              <div id="w-node-d75688a3-098d-c9ba-b823-d9695d76f0bc-2897c137" data-w-id="d75688a3-098d-c9ba-b823-d9695d76f0bc" class="layout-image-wrapper"><img src={{ $help[2]['img'] }} /></div>
              <div id="w-node-d75688a3-098d-c9ba-b823-d9695d76f0be-2897c137" data-w-id="d75688a3-098d-c9ba-b823-d9695d76f0be" class="layout-content2 has-padding-bottom">
                <h3 class="layout-subheading2"><strong>{{ $help[2]['judul'] }}</strong><br /></h3>
                <div class="margin-top margin-small">
                  <p>{{ $help[2]['deskripsi'] }}<br /></p>
                </div>
              </div>
            </div>
          </section>
          <section class="layout1-wrapper has-margin-bottom">
            <div class="layout1-right-align">
              <div id="w-node-_43a098f5-5a21-bde4-aad5-cda24e86354d-2897c137" data-w-id="43a098f5-5a21-bde4-aad5-cda24e86354d" class="layout-content1">
                <h3 class="layout-subheading2"><strong>{{ $help[3]['judul'] }}</strong><br /></h3>
                <div class="margin-top margin-small">
                  <p>{{ $help[3]['deskripsi'] }}<br /></p>
                </div>
              </div>
              <div id="w-node-_43a098f5-5a21-bde4-aad5-cda24e863553-2897c137" data-w-id="43a098f5-5a21-bde4-aad5-cda24e863553" class="layout-image-wrapper is-justify-left"><img src={{ $help[3]['img'] }} loading="lazy" width="466" alt="" sizes="(max-width: 479px) 59vw, (max-width: 767px) 46vw, (max-width: 991px) 47vw, (max-width: 1439px) 279.59375px, 466px" class="layout1-image" /></div>
            </div>
          </section>
        </div>
      </div>
    </div><img src="Assets/bg1.png" loading="lazy" alt="" class="mobile-background-blob1" /><img src="Assets/bg2.png" loading="lazy" alt="" class="mobile-background-blob2" /><img src="Assets/bg3.png" loading="lazy" alt="" class="mobile-background-blob3" />
    <p class="learn-more-text"><strong>Lorem ipsum dolor sit amet consectetur adipisicing elit <br /></strong>‍<a href="https://apply.revou.co/hiring/" target="_blank" class="get-hired-link">Learn more</a></p>
  </div>
