<section class="section-featured-in">
    <div class="page-padding">
      <div class="hired-by-container">
        <div class="padding-vertical padding-xhuge">
          <div class="margin-bottom margin-xlarge">
            <div class="text-align-center">
              <h2 data-w-id="138ac956-5afc-5c05-5c53-9455d7dc50d4" style="opacity:0">As Featured In...</h2>
              <div class="underline-wrapper"><img src="Assets/span.png" loading="lazy" style="opacity:0" data-w-id="138ac956-5afc-5c05-5c53-9455d7dc50d7" alt="" class="featured-in-underline" /></div>
            </div>
          </div>
          <div data-w-id="f91db660-def8-1cf3-68ed-94d98f2b8e6c" style="opacity:0" class="featured-in_component">
            <div class="featured-in_logo-wrapper"><a href="https://dailysocial.id/post/startup-edutech-revou/" target="_blank" class="featured-in_logo-link-block w-inline-block"><img src="https://assets.website-files.com/61af164800e38c4f53c60b4e/61af164800e38c9f21c60b9d_dailysocial%20logo.png" loading="lazy" width="230" alt="" class="featured-in_logo" /></a></div>
            <div class="featured-in_logo-wrapper"><a href="https://www.techinasia.com/exzalora-iprice-marketing-director-launches-startup-school-indonesia" target="_blank" class="featured-in_logo-link-block is-60 w-inline-block"><img src="https://assets.website-files.com/61af164800e38c4f53c60b4e/61af164800e38cdc85c60ba1_Tech%20in%20Asia%20logo.png" loading="lazy" width="288.5" srcset="https://assets.website-files.com/61af164800e38c4f53c60b4e/61af164800e38cdc85c60ba1_Tech%2520in%2520Asia%2520logo-p-500.png 500w, https://assets.website-files.com/61af164800e38c4f53c60b4e/61af164800e38cdc85c60ba1_Tech%20in%20Asia%20logo.png 584w" sizes="(max-width: 479px) 33vw, (max-width: 767px) 26vw, (max-width: 991px) 25vw, (max-width: 1439px) 17vw, 288.5px" alt="" class="featured-in_logo" /></a></div>
            <div class="featured-in_logo-wrapper has-custom-margin"><a href="https://www.medcom.id/teknologi/news-teknologi/aNrXgDPk-revou-sekolah-online-untuk-bangun-skill" target="_blank" class="featured-in_logo-link-block is-60 w-inline-block"><img src="https://assets.website-files.com/61af164800e38c4f53c60b4e/61af164800e38c14f6c60b9e_Medcom%20Logo.png" loading="lazy" width="269" alt="" class="featured-in_logo" /></a></div>
            <div class="featured-in_logo-wrapper has-custom-margin"><a href="https://www.liputan6.com/tekno/read/4472099/revou-siap-ramaikan-pasar-edtech-startup-di-indonesia" target="_blank" class="featured-in_logo-link-block w-inline-block"><img src="https://assets.website-files.com/61af164800e38c4f53c60b4e/61af164800e38c3f47c60b9c_liputan6%20logo.png" loading="lazy" width="231" alt="" class="featured-in_logo" /></a></div>
            <div class="featured-in_logo-wrapper"><a href="https://edukasi.kompas.com/read/2021/03/30/150928471/ini-dia-10-website-universitas-paling-banyak-dikunjungi-awal-2021" target="_blank" class="featured-in_logo-link-block w-inline-block"><img src="https://assets.website-files.com/61af164800e38c4f53c60b4e/61af164800e38c40fac60ba0_Kompas.png" loading="lazy" width="249" alt="" class="featured-in_logo" /></a></div>
            <div class="featured-in_logo-wrapper"><a href="https://inet.detik.com/business/d-5593376/startup-startup-ini-malah-tambah-karyawan-saat-pandemi" target="_blank" class="featured-in_logo-link-block w-inline-block"><img src="https://assets.website-files.com/61af164800e38c4f53c60b4e/61af164800e38c2a5ec60b9f_Detik.png" loading="lazy" width="221" alt="" class="featured-in_logo" /></a></div>
          </div>
        </div>
      </div>
    </div>
  </section>
